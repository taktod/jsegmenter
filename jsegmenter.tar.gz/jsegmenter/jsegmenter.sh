java -Xmx256m -Dfile.encoding=UTF-8 -cp lib/*:conf/*: com.ttProject.jsegmenter.JSegmenter $*
